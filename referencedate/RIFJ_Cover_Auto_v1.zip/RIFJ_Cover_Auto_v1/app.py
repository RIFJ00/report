"""ローカルブラウザーで2つのPDFを選択するための画面。"""
from __future__ import annotations

import base64
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import tempfile
import threading
from urllib.parse import urlparse, parse_qs, quote
import webbrowser

import fitz
from builder import analyze, build, make_cover

TOKEN=secrets.token_urlsafe(24)
ROOT=Path(tempfile.mkdtemp(prefix='rifj_cover_'))
SESSIONS={}
LOCK=threading.Lock()
MAX_UPLOAD=150*1024*1024

HTML=r'''<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>政策リサーチ 資料セット作成</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f4f7fa;color:#17324d;font:16px/1.7 -apple-system,BlinkMacSystemFont,"Hiragino Kaku Gothic ProN",Meiryo,sans-serif}main{max-width:1120px;margin:auto;padding:40px 24px}header{margin-bottom:30px}.brand{font-weight:700;color:#0878a6}h1{font-size:30px;margin:8px 0}p{margin:10px 0;color:#4f6274}.grid{display:grid;grid-template-columns:1fr 1fr;gap:22px}.panel{background:white;border:1px solid #dbe5ec;border-radius:14px;padding:24px}h2{font-size:19px;margin:0 0 20px}label{display:block;font-weight:600;margin-top:17px}input,textarea{font:inherit;width:100%;padding:10px;border:1px solid #b9cbd6;border-radius:6px;background:#fff;color:#17324d}input[type=file]{font-size:14px;background:#f8fbfd}textarea{height:160px;resize:vertical}button,a.download{border:0;border-radius:7px;background:#0878a6;color:#fff;font:600 16px/1.4 inherit;padding:14px 20px;cursor:pointer;display:inline-block;text-decoration:none;margin:6px 8px 6px 0}button:disabled{opacity:.45;cursor:default}.muted{font-size:13px;color:#607486}.status{margin:18px 0;min-height:28px;color:#0878a6;white-space:pre-wrap}.error{color:#b42435}img{max-width:100%;border:1px solid #d9e2e8}.preview{margin-top:20px}.results{margin-top:20px}.note{margin-top:24px;border-top:1px solid #e0e9ee;padding-top:14px;font-size:13px}@media(max-width:800px){.grid{grid-template-columns:1fr}main{padding:22px 16px}h1{font-size:25px}}
</style><main><header><div class="brand">政策リサーチ</div><h1>企業宛の資料セットを作成</h1><p>企業資料と会議資料のPDFを選択すると、表紙の企業名・説明文を自動入力します。</p></header>
<div class="grid"><section class="panel"><h2>1. ２つのPDFを添付</h2><label for="companyfile">企業資料</label><input id="companyfile" type="file" accept="application/pdf,.pdf"><label for="meetingfile">会議資料</label><input id="meetingfile" type="file" accept="application/pdf,.pdf"><p class="muted">各100ページまで。２つのPDFの合計は150MBまで。</p><div id="counts" class="muted"></div><div id="status" class="status" role="status" aria-live="polite">２つのPDFを選択してください。</div></section>
<section class="panel"><h2>2. 表紙の内容</h2><label for="company">送付先企業名</label><input id="company" maxlength="100" placeholder="自動入力"><label for="meeting">会議名</label><input id="meeting" maxlength="100" placeholder="自動入力"><label for="description">タイトル下の説明文</label><textarea id="description" maxlength="500" placeholder="自動入力"></textarea><p class="muted">タイトルは「企業名様参考資料」。右下に「作成者:一般社団法人日本みらい研」を表示します。</p><button id="generate" disabled>PPTX・PDFを作成</button></section></div>
<div class="preview" id="previewbox" hidden><h2>表紙プレビュー</h2><img id="preview" alt="作成する表紙"></div><section id="results" class="results" hidden><h2>完成したファイル</h2><div id="downloads"></div></section><p class="note">構成は、表紙＋企業資料の全ページ＋会議資料の全ページ。PPTXの表紙は文字編集可能で、本文は画像として収録します。PDFの本文は元資料を保持します。添付資料の内容・事実関係の検証は行いません。</p></main>
<script>
const token='__TOKEN__';let session=null;let revision=0;
const el=id=>document.getElementById(id);
function status(s,bad=false){el('status').textContent=s;el('status').className='status'+(bad?' error':'')}
async function call(path,body){const r=await fetch(path,{method:'POST',headers:{'X-RIFJ-Token':token},body});const j=await r.json();if(!r.ok)throw Error(j.error||'処理に失敗しました');return j}
async function analyzeFiles(){const rev=++revision;session=null;el('generate').disabled=true;el('results').hidden=true;el('previewbox').hidden=true;el('counts').textContent='';const c=el('companyfile').files[0],m=el('meetingfile').files[0];if(!c||!m){status('２つのPDFを選択してください。');return}if(c.size+m.size>150*1024*1024){status('PDFの合計サイズを150MB以内にしてください。',true);return}status('PDFの内容を読み取っています…');try{const data=new FormData();data.append('company_pdf',c);data.append('meeting_pdf',m);const j=await call('/analyze',data);if(rev!==revision)return;session=j.session;for(const key of ['company','meeting','description'])el(key).value=j.metadata[key];el('counts').textContent=`表紙１ページ＋企業資料${j.metadata.company_pages}ページ＋会議資料${j.metadata.meeting_pages}ページ＝全${j.metadata.total_pages}ページ`;if(j.preview){el('preview').src=j.preview;el('previewbox').hidden=false}status(j.metadata.warnings.length?j.metadata.warnings.join('\n'):'表紙を自動入力しました。内容を確認して作成できます。',j.metadata.warnings.length>0);el('generate').disabled=false}catch(e){if(rev===revision)status(e.message,true)}}
el('companyfile').addEventListener('change',analyzeFiles);el('meetingfile').addEventListener('change',analyzeFiles);
el('generate').addEventListener('click',async()=>{if(!session)return;const rev=revision;el('generate').disabled=true;status('表紙と資料セットを作成しています…');try{const values={session};for(const key of ['company','meeting','description'])values[key]=el(key).value;const j=await call('/build',JSON.stringify(values));if(rev!==revision)return;el('downloads').replaceChildren();for(const f of j.files){const a=document.createElement('a');a.href=f.url;a.textContent=f.label;a.className='download';a.download=f.name;el('downloads').append(a)}el('preview').src=j.preview;el('previewbox').hidden=false;el('results').hidden=false;status('作成しました。下のボタンから保存してください。')}catch(e){if(rev===revision)status(e.message,true)}finally{if(rev===revision)el('generate').disabled=false}});
</script></html>'''


def preview(path):
    with fitz.open(path) as d:
        data=d[0].get_pixmap(matrix=fitz.Matrix(1,1)).tobytes('png')
    return 'data:image/png;base64,'+base64.b64encode(data).decode()


class Handler(BaseHTTPRequestHandler):
    def log_message(self,format,*args):
        pass

    def send(self,status,data,ctype='application/json; charset=utf-8',extra=None):
        if isinstance(data,dict): data=json.dumps(data,ensure_ascii=False).encode()
        if isinstance(data,str): data=data.encode()
        self.send_response(status)
        self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        if extra:
            for k,v in extra.items(): self.send_header(k,v)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        url=urlparse(self.path)
        if url.path=='/':
            return self.send(200,HTML.replace('__TOKEN__',TOKEN),'text/html; charset=utf-8')
        if url.path=='/download':
            q=parse_qs(url.query)
            sid=q.get('session',[''])[0]
            item=q.get('item',[''])[0]
            session=SESSIONS.get(sid)
            if not session or item not in session.get('files',{}):
                return self.send(404,dict(error='ファイルが見つかりません。'))
            p=session['files'][item]
            types={'.pdf':'application/pdf','.pptx':'application/vnd.openxmlformats-officedocument.presentationml.presentation','.zip':'application/zip','.png':'image/png'}
            return self.send(200,p.read_bytes(),types.get(p.suffix,'application/octet-stream'),{'Content-Disposition':"attachment; filename*=UTF-8''"+quote(p.name)})
        self.send(404,dict(error='ページが見つかりません。'))

    def do_POST(self):
        if self.headers.get('X-RIFJ-Token')!=TOKEN:
            return self.send(403,dict(error='画面を開き直してください。'))
        try:
            n=int(self.headers.get('Content-Length','0'))
            if n<=0 or n>MAX_UPLOAD+1024*1024:
                return self.send(400,dict(error='送信できるPDFの合計は150MBまでです。'))
            data=self.rfile.read(n)
            if self.path=='/analyze':
                ctype=self.headers.get('Content-Type','')
                msg=BytesParser(policy=default).parsebytes(('Content-Type: '+ctype+'\r\nMIME-Version: 1.0\r\n\r\n').encode()+data)
                found={}
                if not msg.is_multipart(): raise ValueError('２つのPDFを選択してください。')
                for part in msg.iter_parts():
                    name=part.get_param('name',header='content-disposition')
                    if name in ('company_pdf','meeting_pdf'):
                        found[name]=part.get_payload(decode=True)
                if len(found)!=2: raise ValueError('企業資料と会議資料の２つを指定してください。')
                if sum(len(v) for v in found.values())>MAX_UPLOAD: raise ValueError('PDFの合計は150MBまでです。')
                sid=secrets.token_urlsafe(24)
                folder=ROOT/sid
                folder.mkdir()
                for k,v in found.items():
                    (folder/(k+'.pdf')).write_bytes(v)
                c,m=folder/'company_pdf.pdf',folder/'meeting_pdf.pdf'
                meta=analyze(c,m)
                p=''
                if meta['company']:
                    make_cover(meta,folder/'preview.pdf')
                    p=preview(folder/'preview.pdf')
                SESSIONS[sid]=dict(folder=folder,company=c,meeting=m)
                return self.send(200,dict(session=sid,metadata=meta,preview=p))
            if self.path=='/build':
                req=json.loads(data)
                sid=req.get('session','')
                session=SESSIONS.get(sid)
                if not session: raise ValueError('２つのPDFを選び直してください。')
                with LOCK:
                    out=session['folder']/secrets.token_hex(8)
                    meta,files=build(session['company'],session['meeting'],out,req)
                    session['files']={}
                    result=[]
                    labels=['PDFを保存','PPTXを保存','表紙PDFを保存','表紙画像を保存','一式ZIPを保存']
                    for p,label in zip(files,labels):
                        key=secrets.token_hex(8)
                        session['files'][key]=p
                        result.append(dict(name=p.name,label=label,url='/download?session='+quote(sid)+'&item='+key))
                return self.send(200,dict(metadata=meta,files=result,preview=preview(files[2])))
            return self.send(404,dict(error='処理が見つかりません。'))
        except (ValueError,fitz.FileDataError,fitz.EmptyFileError) as e:
            self.send(400,dict(error=str(e)))
        except Exception as e:
            self.send(500,dict(error='作成できませんでした。PDFの形式と保存先を確認してください。 '+str(e)))


def main():
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    url=f'http://127.0.0.1:{server.server_port}/'
    print('政策リサーチ 資料セット作成')
    print('ブラウザーで '+url+' を開いてください。終了はControl+C。')
    threading.Timer(.6,lambda:webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        import shutil
        shutil.rmtree(ROOT,ignore_errors=True)


if __name__=='__main__': main()
