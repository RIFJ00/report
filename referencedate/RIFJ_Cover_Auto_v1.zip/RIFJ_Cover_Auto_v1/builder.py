"""政策リサーチ: 2つのPDFから表紙・PPTX・PDF一式を作成する。

外部サービスへ送信しないローカル処理。PPTXはOpen XMLを直接生成する。
表紙は編集可能なテキスト、添付ページは高解像度画像として収録する。
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import io
import json
from pathlib import Path
import re
import unicodedata
import zipfile
from xml.sax.saxutils import escape

import fitz

WIDTH, HEIGHT = 1280, 720
AUTHOR = "作成者:一般社団法人日本みらい研"
FONT_NAME = "Droid Sans Fallback"
FONT = fitz.Font("japan")
NAVY, BLUE, GRAY = "17324D", "0878A6", "4F6274"
MAX_PAGES = 100


def clean(text):
    text = unicodedata.normalize("NFKC", text)
    return re.sub(r"[ \t\u3000]+", " ", text).strip()


def compact(text):
    return re.sub(r"\s+", "", clean(text))


def open_pdf(path):
    doc = fitz.open(path)
    if doc.needs_pass:
        doc.close()
        raise ValueError("パスワード付きPDFは、解除したファイルを指定してください。")
    if not doc.is_pdf or not 1 <= len(doc) <= MAX_PAGES:
        doc.close()
        raise ValueError(f"1〜{MAX_PAGES}ページのPDFを指定してください。")
    return doc


def pdf_text(path):
    with open_pdf(path) as doc:
        return "\n".join(page.get_text() for page in doc), len(doc)


def infer_company(text):
    lines = [clean(x) for x in text.splitlines() if clean(x)]
    for line in lines[:12]:
        if re.search(r"[|｜]", line):
            candidate = re.split(r"[|｜]", line)[0].strip()
            if 2 <= len(candidate) <= 50 and not re.search(r"^\d|会議のポイント|参考数字|出典|出所", candidate):
                return re.sub(r"(?:様|御中)$", "", candidate)
    for line in lines[:15]:
        m = re.search(r"(?:企業名|会社名|対象企業)\s*[:：]\s*(.+)", line)
        if m:
            return m.group(1).strip()
    for line in lines[:10]:
        if re.search(r"株式会社|合同会社|ホールディングス|自動車|金属|印刷|電力|電機|銀行|商事|物産", line) and "日本みらい研" not in line:
            return re.split(r"[|｜×]", line)[0].strip()[:50]
    return ""


def infer_meeting(text):
    for raw in text.splitlines():
        line = clean(raw)
        if "会議のポイント" == line or "日本みらい研" in line:
            continue
        if re.search(r"第\s*[0-9一二三四五六七八九十百]+\s*回", line) and re.search(r"会議|会合|検討会|審議会|委員会|本部|研究会|調査会", line):
            value = re.split(r"[|｜]", line)[0].strip()
            value = re.sub(r"第\s*(\d+)\s*回\s*", r"第\1回 ", value)
            return value[:80]
    for raw in text.splitlines()[:15]:
        line = clean(raw)
        if re.search(r"会議|会合|検討会|審議会|委員会|研究会|調査会", line) and "ポイント" not in line and len(line) <= 80:
            return line
    return "関連会議"


def infer_date(text):
    m = re.search(r"(20\d{2})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日", text)
    if not m:
        m = re.search(r"(20\d{2})[-/](\d{1,2})[-/](\d{1,2})", text)
    if m:
        try:
            return datetime(*map(int, m.groups())).strftime("%Y年%m月%d日")
        except ValueError:
            pass
    return ""


def infer_topics(text):
    t = compact(text)
    ordered = ["フィジカルAI", "ロボティクス", "半導体", "情報通信", "サイバーセキュリティ", "蓄電池", "電池", "水素", "創薬", "先端医療", "デジタル", "エネルギー", "防衛", "宇宙", "インフラ", "金融", "農業", "人材育成"]
    # 見出しにある語を優先し、対象PDFに存在する語だけを採用する。
    head = compact("\n".join(text.splitlines()[:8]))
    found = [x for x in ordered if x in head]
    found += [x for x in ordered if x in t and x not in found]
    return found[:2]


def analyze(company_pdf, meeting_pdf):
    ct, cn = pdf_text(company_pdf)
    mt, mn = pdf_text(meeting_pdf)
    company, meeting = infer_company(ct), infer_meeting(mt)
    topics = infer_topics(ct)
    focus = f"貴社の{'・'.join(topics)}分野" if topics else "貴社事業"
    description = (f"{meeting}の政策動向と、{focus}との接点を整理した参考資料です。"
                   "企業向けの関連性分析と、会議の主要論点・今後の焦点をまとめています。")
    warnings = []
    if not company:
        warnings.append("企業名を自動判定できませんでした。送付先企業名を入力してください。")
    if not ct.strip() or not mt.strip():
        warnings.append("文字を抽出できないページがあります。OCR処理済みPDF、または企業名・会議名・説明文の入力をご利用ください。")
    return dict(company=company, meeting=meeting, description=description,
                source_date=infer_date(mt), company_pages=cn, meeting_pages=mn,
                total_pages=1+cn+mn, warnings=warnings)


def text_width(text, size):
    return FONT.text_length(text, fontsize=size)


def wrap(text, width, size):
    lines = []
    for paragraph in text.splitlines():
        line = ""
        for c in paragraph:
            if line and text_width(line+c, size) > width:
                if c in "、。）」』】！？":
                    line += c
                    lines.append(line)
                    line = ""
                else:
                    lines.append(line)
                    line = c
            else:
                line += c
        lines.append(line)
    return lines


def cover_elements(meta):
    company = meta["company"].strip()
    if not company or len(company) > 100:
        raise ValueError("送付先企業名を1〜100文字で入力してください。")
    if not meta["description"].strip() or len(meta["description"]) > 500:
        raise ValueError("説明文を1〜500文字で入力してください。")
    if not meta["meeting"].strip() or len(meta["meeting"]) > 100:
        raise ValueError("会議名を1〜100文字で入力してください。")
    title = company + "様参考資料"
    title_size = min(52, 1120 / max(text_width(title, 1), 1))
    # 長い企業名も読める大きさを維持して2行にする。
    title_size = max(34, title_size)
    title_lines = wrap(title, 1120, title_size)
    if len(title_lines) > 2:
        raise ValueError("企業名が長すぎます。表紙用の企業名を短くしてください。")
    els = []
    def add(text, x, y, w, size, color=NAVY, bold=False, align="left"):
        for line in wrap(text, w, size):
            els.append(dict(text=line,x=x,y=y,w=w,h=size*1.45,size=size,color=color,bold=bold,align=align))
            y += size*1.6
        return y
    add("政策リサーチ", 80, 54, 900, 25, BLUE, True)
    title_y = 165 if len(title_lines) == 1 else 124
    for i, line in enumerate(title_lines):
        add(line, 80, title_y+i*66, 1120, title_size, NAVY, True)
    desc_lines = wrap(meta["description"], 1100, 25)
    if len(desc_lines) > 5:
        raise ValueError("説明文が長すぎます。表紙に収まるよう250文字程度に短くしてください。")
    y=title_y + (len(title_lines)-1)*66 + 94
    for line in desc_lines:
        add(line,80,y,1100,25,GRAY)
        y+=40
    contents_y = max(460, y+30)
    if contents_y+122 > 620:
        raise ValueError("表紙の文章が収まりません。説明文を短くしてください。")
    add("収録内容",80,contents_y,1080,20,BLUE,True)
    add(f"01　企業資料　政策動向と貴社事業の接点（{meta['company_pages']}ページ）",80,contents_y+42,1120,23)
    add(f"02　会議資料　{meta['meeting']}（{meta['meeting_pages']}ページ）",80,contents_y+82,1120,23)
    add(AUTHOR,420,650,780,22,NAVY,False,"right")
    return els


def make_cover(meta, out_path):
    doc=fitz.open()
    page=doc.new_page(width=WIDTH*.75,height=HEIGHT*.75)
    page.insert_font(fontname="RIFJ",fontbuffer=FONT.buffer)
    for e in cover_elements(meta):
        size=e['size']*.75
        x=e['x']*.75
        if e['align']=='right':
            x=(e['x']+e['w'])*.75-text_width(e['text'],size)
        rgb=tuple(int(e['color'][i:i+2],16)/255 for i in (0,2,4))
        page.insert_text((x,(e['y']+e['size']*.98)*.75),e['text'],fontname="RIFJ",fontsize=size,color=rgb)
    doc.set_metadata(dict(title=meta['company']+"様参考資料",author="一般社団法人日本みらい研",subject=meta['description'],creator="政策リサーチ 資料セット自動作成"))
    doc.subset_fonts()
    doc.save(out_path,garbage=4,deflate=True)
    doc.close()


def xml(text):
    return escape(str(text), {'"': '&quot;'})


def emu(px):
    return round(px*9525)


def text_shape(e, i):
    size=round(e['size']*.75*100)
    return f'''<p:sp><p:nvSpPr><p:cNvPr id="{i}" name="{xml(e['text'][:32])}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>
<p:spPr><a:xfrm><a:off x="{emu(e['x'])}" y="{emu(e['y'])}"/><a:ext cx="{emu(e['w'])}" cy="{emu(e['h'])}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr>
<p:txBody><a:bodyPr wrap="none" lIns="0" rIns="0" tIns="0" bIns="0"/><a:lstStyle/><a:p><a:pPr algn="{'r' if e['align']=='right' else 'l'}"/><a:r><a:rPr lang="ja-JP" sz="{size}" b="{int(e['bold'])}"><a:solidFill><a:srgbClr val="{e['color']}"/></a:solidFill><a:latin typeface="{FONT_NAME}"/><a:ea typeface="{FONT_NAME}"/><a:cs typeface="{FONT_NAME}"/></a:rPr><a:t>{xml(e['text'])}</a:t></a:r><a:endParaRPr lang="ja-JP" sz="{size}"/></a:p></p:txBody></p:sp>'''


def slide_xml(content):
    return f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>{content}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'''


def rels(items):
    return '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="{i}" Type="http://schemas.openxmlformats.org/{t}" Target="{xml(p)}"/>' for i,t,p in items)+'</Relationships>'


def make_pptx(meta, company_pdf, meeting_pdf, out_path):
    """外部ライブラリーなしで、標準Open XMLのPPTXを生成。"""
    pages=[]
    for path in (company_pdf,meeting_pdf):
        with open_pdf(path) as doc:
            for p in doc:
                # A4・縦長ページも縦横比を保ち、見切れずに収録する。
                pix=p.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False)
                ratio=min(WIDTH/p.rect.width,HEIGHT/p.rect.height)
                w,h=p.rect.width*ratio,p.rect.height*ratio
                pages.append((pix.tobytes('png'),(WIDTH-w)/2,(HEIGHT-h)/2,w,h))
    count=1+len(pages)
    ns='http://schemas.openxmlformats.org/presentationml/2006/main'
    ans='http://schemas.openxmlformats.org/drawingml/2006/main'
    with zipfile.ZipFile(out_path,'w',zipfile.ZIP_DEFLATED) as z:
        def put(name,content): z.writestr(name,content)
        overrides=[('/ppt/presentation.xml','application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml'),('/ppt/slideMasters/slideMaster1.xml','application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml'),('/ppt/slideLayouts/slideLayout1.xml','application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml'),('/ppt/theme/theme1.xml','application/vnd.openxmlformats-officedocument.theme+xml'),('/docProps/core.xml','application/vnd.openxmlformats-package.core-properties+xml'),('/docProps/app.xml','application/vnd.openxmlformats-officedocument.extended-properties+xml')]
        overrides += [(f'/ppt/slides/slide{i}.xml','application/vnd.openxmlformats-officedocument.presentationml.slide+xml') for i in range(1,count+1)]
        put('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/>'+''.join(f'<Override PartName="{p}" ContentType="{t}"/>' for p,t in overrides)+'</Types>')
        put('_rels/.rels',rels([('rId1','officeDocument/2006/relationships/officeDocument','ppt/presentation.xml'),('rId2','package/2006/relationships/metadata/core-properties','docProps/core.xml'),('rId3','officeDocument/2006/relationships/extended-properties','docProps/app.xml')]))
        put('docProps/core.xml',f'<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>{xml(meta["company"])}様参考資料</dc:title><dc:creator>一般社団法人日本みらい研</dc:creator><dc:description>{xml(meta["description"])}</dc:description></cp:coreProperties>')
        put('docProps/app.xml',f'<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>政策リサーチ</Application><Slides>{count}</Slides></Properties>')
        ids=''.join(f'<p:sldId id="{255+i}" r:id="rId{i+1}"/>' for i in range(1,count+1))
        put('ppt/presentation.xml',f'<p:presentation xmlns:p="{ns}" xmlns:a="{ans}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>{ids}</p:sldIdLst><p:sldSz cx="{emu(WIDTH)}" cy="{emu(HEIGHT)}" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>')
        put('ppt/_rels/presentation.xml.rels',rels([('rId1','officeDocument/2006/relationships/slideMaster','slideMasters/slideMaster1.xml')]+[(f'rId{i+1}','officeDocument/2006/relationships/slide',f'slides/slide{i}.xml') for i in range(1,count+1)]))
        base='<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree>'
        put('ppt/slideMasters/slideMaster1.xml',f'<p:sldMaster xmlns:p="{ns}" xmlns:a="{ans}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><p:cSld>{base}</p:cSld><p:clrMap accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" bg1="lt1" bg2="lt2" folHlink="folHlink" hlink="hlink" tx1="dk1" tx2="dk2"/><p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles/></p:sldMaster>')
        put('ppt/slideMasters/_rels/slideMaster1.xml.rels',rels([('rId1','officeDocument/2006/relationships/slideLayout','../slideLayouts/slideLayout1.xml'),('rId2','officeDocument/2006/relationships/theme','../theme/theme1.xml')]))
        put('ppt/slideLayouts/slideLayout1.xml',f'<p:sldLayout xmlns:p="{ns}" xmlns:a="{ans}" type="blank" preserve="1"><p:cSld name="Blank">{base}</p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>')
        put('ppt/slideLayouts/_rels/slideLayout1.xml.rels',rels([('rId1','officeDocument/2006/relationships/slideMaster','../slideMasters/slideMaster1.xml')]))
        colors={'dk1':NAVY,'lt1':'FFFFFF','dk2':GRAY,'lt2':'F2F7FA','accent1':BLUE,'accent2':'76C4B8','accent3':'598DB8','accent4':'7F8EA0','accent5':'A5CADB','accent6':'C1DDD5','hlink':'0563C1','folHlink':'954F72'}
        scheme=''.join(f'<a:{k}><a:srgbClr val="{v}"/></a:{k}>' for k,v in colors.items())
        font=f'<a:latin typeface="{FONT_NAME}"/><a:ea typeface="{FONT_NAME}"/><a:cs typeface="{FONT_NAME}"/>'
        fill='<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
        line='<a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>'
        put('ppt/theme/theme1.xml',f'<a:theme xmlns:a="{ans}" name="政策リサーチ"><a:themeElements><a:clrScheme name="RIFJ">{scheme}</a:clrScheme><a:fontScheme name="RIFJ"><a:majorFont>{font}</a:majorFont><a:minorFont>{font}</a:minorFont></a:fontScheme><a:fmtScheme name="RIFJ"><a:fillStyleLst>{fill*3}</a:fillStyleLst><a:lnStyleLst>{line*3}</a:lnStyleLst><a:effectStyleLst>{"<a:effectStyle><a:effectLst/></a:effectStyle>"*3}</a:effectStyleLst><a:bgFillStyleLst>{fill*3}</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>')
        put('ppt/slides/slide1.xml',slide_xml(''.join(text_shape(e,i+2) for i,e in enumerate(cover_elements(meta)))))
        put('ppt/slides/_rels/slide1.xml.rels',rels([('rId1','officeDocument/2006/relationships/slideLayout','../slideLayouts/slideLayout1.xml')]))
        for i,(data,x,y,w,h) in enumerate(pages,2):
            put(f'ppt/media/page{i}.png',data)
            pic=f'<p:pic><p:nvPicPr><p:cNvPr id="2" name="添付資料 {i-1}ページ"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="rId2"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="{emu(x)}" y="{emu(y)}"/><a:ext cx="{emu(w)}" cy="{emu(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>'
            put(f'ppt/slides/slide{i}.xml',slide_xml(pic))
            put(f'ppt/slides/_rels/slide{i}.xml.rels',rels([('rId1','officeDocument/2006/relationships/slideLayout','../slideLayouts/slideLayout1.xml'),('rId2','officeDocument/2006/relationships/image',f'../media/page{i}.png')]))


def safe_name(name):
    return re.sub(r'[\\/:*?"<>|\x00-\x1f]', '_', name).strip('. ')[:70] or 'RIFJ'


def build(company_pdf, meeting_pdf, output_dir, overrides=None):
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    meta=analyze(company_pdf,meeting_pdf)
    for k,v in (overrides or {}).items():
        if k in ('company','meeting','description'):
            meta[k]=str(v).strip()
    cover_elements(meta)
    stamp=datetime.now(timezone(timedelta(hours=9))).strftime('%Y%m%d')
    base=safe_name(meta['company'])+'_参考資料_'+stamp
    cover=output_dir/(base+'_表紙.pdf')
    pdf=output_dir/(base+'.pdf')
    pptx=output_dir/(base+'.pptx')
    make_cover(meta,cover)
    with fitz.open(cover) as result:
        for p in (company_pdf,meeting_pdf):
            with open_pdf(p) as d:
                result.insert_pdf(d,links=True,annots=True)
        result.set_toc([[1,'表紙',1],[1,'企業資料',2],[1,meta['meeting'],2+meta['company_pages']]])
        result.save(pdf,garbage=4,deflate=True)
    make_pptx(meta,company_pdf,meeting_pdf,pptx)
    with fitz.open(cover) as d:
        d[0].get_pixmap(matrix=fitz.Matrix(4/3,4/3)).save(output_dir/(base+'_表紙.png'))
    files=[pdf,pptx,cover,output_dir/(base+'_表紙.png')]
    bundle=output_dir/(base+'_一式.zip')
    with zipfile.ZipFile(bundle,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files: z.write(p,p.name)
    return meta,files+[bundle]


if __name__=='__main__':
    parser=argparse.ArgumentParser(description='企業PDFと会議PDFから、表紙付きPPTX・PDFを作成')
    parser.add_argument('company_pdf',type=Path)
    parser.add_argument('meeting_pdf',type=Path)
    parser.add_argument('--output',type=Path,default=Path('output'))
    parser.add_argument('--company')
    parser.add_argument('--meeting')
    parser.add_argument('--description')
    args=parser.parse_args()
    meta,files=build(args.company_pdf,args.meeting_pdf,args.output,{k:v for k,v in vars(args).items() if k in ('company','meeting','description') and v})
    print(json.dumps({'metadata':meta,'files':[str(p) for p in files]},ensure_ascii=False,indent=2))
